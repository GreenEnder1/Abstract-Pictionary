import React from "react"

export function SettingsRight()
{
    return (
        <>
        <div className="settings-right">
        </div>
        </>
    )
}