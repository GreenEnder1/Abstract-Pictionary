import React, {useEffect, useState} from 'react'
import { Canvas } from './Canvas'
import {useCanvas} from './CanvasContext'
import { Header, SettingsLeft, SettingsRight } from './Header'
import { Footer } from './Footer';
import { Overlay } from './Overlay'

function App() {
  const [initialTime, setInitialTime] = useState(60); // default 60 seconds
  const [isRunning, setIsRunning] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [canUpdate, setCanUpdate] = useState(false);
  const [word, setWord] = useState("");

  const handleStart = () => {
      setIsRunning(true);
  };
  
  const toggleOverlay = () => {
    setIsOpen(!isOpen);
  }

  const handleComplete = () => {
      setIsRunning(false);
      updateScore();
      setIsOpen(true);
  };

  const updateScore = () =>
  {
    setCanUpdate(true);
  }

  const handleTimeChange = (newTime) => {
    setInitialTime(newTime);
  };
  return (
    <>
      <Header initialTime={initialTime} isRunning={isRunning} handleComplete={handleComplete} word={word} setWord={setWord}/>
      <hr/>
      <div className="body-elements">
      <SettingsLeft onStart={handleStart} isRunning={isRunning}/>
      <Canvas/>
      <SettingsRight isRunning={isRunning} onClick={handleTimeChange}/>
      </div>
      <Overlay isOpen={isOpen} onClose={toggleOverlay}>
        <h1 style={{color:"black"}}>Match Score: <Score canUpdate={canUpdate} word={word}/></h1>
      </Overlay>
      <hr/>
      <Footer/>
    </>
  );
}

function Score({canUpdate, word})
{
  const { canvasRef } = useCanvas();
  const canvas = canvasRef.current;
  const [result, setResult] = useState("Loading...");
  const [isLoading, setIsLoading] = useState(true);
  useEffect(() => {
    const fetchData = async() =>  
    {
      if (canUpdate) {
        canvas.toBlob(async (blob) => {
          const formData = new FormData();
          formData.append('image', blob, "canvas-image.jpeg");
          setIsLoading(true);
          try
          {
            const response = await fetch('http://localhost:5000/process', {
              method: 'POST',
              body: formData,
            });
            const data = await response.json();
            console.log('Response from backend:', data[word.toLowerCase()]);
            let JSONresult = data[word.toLowerCase()];
            setResult(Math.round(JSONresult * 1000));
          }
          catch (error)
          {
            console.error('Error:', error);
            setResult(-1);
          }
          finally
          {
            setIsLoading(false);
          }
          }, 'image/jpeg');
      }
    }
    fetchData();
  }, []);
  //Find 
  console.log("Returning ", result);
  if (isLoading)
  {
    return (
      <>
      Loading...
      </>
    )
  }
  return (
    <>
    {result}
    </>
  );
}

export default App;
