'''
from flask import Flask, request, jsonify
from flask_cors import CORS
from PIL import Image
import random
import io

app = Flask(__name__)
CORS(app)

@app.route('/process', methods=['POST'])
def process_image():
    files = request.files.getlist('data')
    print(type(files), files)
    image = None
    word = None
    for index, file in enumerate(files):
        if (index == 1):
            image = Image.open(io.BytesIO(file.stream()))
            image.show()
        else:
            word = file.stream()
    result = round(random.random(), 2)

    return jsonify({'result': result})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
'''

'''
from flask import Flask, request, jsonify
from flask_cors import CORS
from PIL import Image
import random
import io

app = Flask(__name__)
CORS(app)

@app.route('/process', methods=['POST'])
def process_image():
    files = request.files.getlist('data')
    # print(type(files), files)
    image = None
    word = None
    print(len(files))
    for index, file in enumerate(files):
        if index == 0:
            image = Image.open(file.stream)
            image = image.convert('RGB')
            # print(type(image))
            image.show()
        else:
            # Try to read and decode as text, but if it fails, handle it gracefully
            try:
                word = file.stream.read().decode('utf-8')
                print(word)
            except UnicodeDecodeError:
                word = "Non-text file or improper encoding."
                

    result = round(random.random(), 2)

    return jsonify({'result': result})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
'''

from flask import Flask, request, jsonify
from flask_cors import CORS
from PIL import Image
import random
import io

from forward_pass import scoring_main

app = Flask(__name__)
CORS(app)

@app.route('/process', methods=['POST'])
def process_image():
    imageFile = request.files['image'].read()
    print(imageFile)
    image = Image.open(io.BytesIO(imageFile))
    result = round(random.random(), 2)
    return scoring_main({'data': [image]})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)