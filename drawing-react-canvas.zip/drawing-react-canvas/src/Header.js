import React, {useEffect, useState} from 'react'
import {useCanvas} from "./CanvasContext"

export function Header({ initialTime, isRunning, handleComplete, word, setWord })
{
    const headerPrefix = "Match the Vibe!";
    return(
        <>
        <div className="header-elements">
            <p>Vibe Gogh</p>
            <p>{headerPrefix}<HeaderWord isRunning={isRunning} word={word} setWord={setWord}/></p>
            <p><Timer initialTime={initialTime} isRunning={isRunning} onComplete={handleComplete} /></p>
        </div>
        </>
    )
}

// TODO integrate with word list
function HeaderWord ({isRunning, word, setWord})
{
    const words = [ "Happiness",
                    "Dreadful",
                    "Creativity",
                    "Time",
                    "Gray",
                    "Growing",
                    "Reality",
                    "Kindness",
                    "Expression",
                    "Fairness"];
    useEffect(() => {
        const chooseRandomWord = () => {
            const randomIndex = Math.floor(Math.random() * words.length);
            setWord(" - " + words[randomIndex]);
        };

        if (isRunning && word == "") {
            chooseRandomWord();
        }
        else if (!isRunning)
        {
            setWord("");
        }

        return () => {
            // This cleanup function runs when isRunning changes to false
            // You can add any cleanup code here if needed
        };
    }, [isRunning, words]);

    return (
        <b>{word}</b>
    )
}

function Timer({initialTime, isRunning, onComplete})
{
    const [time, setTime] = useState(initialTime);

    useEffect(() => {
        setTime(initialTime);
    }, [initialTime]);

    useEffect(() => {
        if (!isRunning) return;
    
        const interval = setInterval(() => {
          setTime((prevTime) => {
            if (prevTime < 1) {
              clearInterval(interval);
              onComplete();
              return initialTime;
            }
            return prevTime - 1;
          });
        }, 1000);
    
        return () => clearInterval(interval);
    }, [isRunning, onComplete]);
    return (
        <>
        {Math.floor(time/60)}:{(time % 60 < 10) ? "0" + time % 60 : time % 60}
        </>
    )
}

export function SettingsLeft({onStart, isRunning})
{
    const { clearCanvas } = useCanvas()
    const [initialTime, setInitialTime] = useState(60); // default 60 seconds

    const handleStart = () => {
        onStart(initialTime);
        return clearCanvas;
    };    

    return (
        <div className="settings-left">
        <button onClick={handleStart} disabled={isRunning} style={{padding:30, fontSize:30}}>
            Start Game
        </button>
        </div>
    );
}

export function SettingsRight({isRunning, onClick})
{
    return (
        <>
        <div className="settings-right">
            <h1>Timer Settings</h1>
            <button onClick={() => onClick(1)} disabled={isRunning}>1 second</button>
            <br/>
            <button onClick={() => onClick(30)} disabled={isRunning}>30 seconds</button>
            <br/>
            <button onClick={() => onClick(60)} disabled={isRunning}>1 minute</button>
            <br/>
            <button onClick={() => onClick(180)} disabled={isRunning}>3 minutes</button>
            <br/>
            <button onClick={() => onClick(300)} disabled={isRunning}>5 minutes</button>
            <br/>
            <button onClick={() => onClick(Math.floor(Math.random() * 300))} disabled={isRunning}>Surprise Me!</button>
        </div>
        </>
    );
}